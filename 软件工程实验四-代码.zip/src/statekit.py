# -*- coding: utf-8 -*-
"""状态机骨架：转移表驱动的有限状态机。

B1~B3 三个状态机共用本模块。每个状态机只负责声明"转移表"（源状态、事件、
守卫、目标状态、动作）和少量动作函数，运行逻辑（匹配、执行、记录）都在这里，
因此代码结构与 UML 状态图一一对应。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple


@dataclass
class Transition:
    """一条转移：src --[event][guard] / action--> dst。"""

    src: Any
    event: str
    dst: Any
    action: Optional[Callable[["StateMachine", Dict[str, Any]], None]] = None
    guard: Optional[Callable[["StateMachine", Dict[str, Any]], bool]] = None
    label: str = ""

    def matched(self, state: Any, event: str, sm: "StateMachine", ctx: Dict[str, Any]) -> bool:
        if self.src is not state or self.event != event:
            return False
        return True if self.guard is None else bool(self.guard(sm, ctx))


class StateMachine:
    """转移表驱动的有限状态机。"""

    def __init__(self, name: str, init_state: Any, transitions: List[Transition]) -> None:
        self.name = name
        self.state = init_state
        self._transitions = list(transitions)
        self.history: List[Tuple[Any, str, Any]] = []
        self.verbose = True

    # ---------- 运行 ----------
    def send(self, event: str, **ctx: Any) -> bool:
        """投递一个事件；命中转移则执行动作并切换状态，返回是否发生转移。"""
        for t in self._transitions:
            if not t.matched(self.state, event, self, ctx):
                continue
            src = self.state
            if t.action is not None:
                t.action(self, ctx)
            self.state = t.dst
            tag = t.label or event
            self.history.append((src, tag, self.state))
            if self.verbose:
                print(f"  {src.value:<5s} --[{tag}]--> {self.state.value}")
            return True
        return False

    def reset(self, state: Any) -> None:
        self.state = state
        self.history.clear()

    # ---------- 便于断言与展示 ----------
    @property
    def path(self) -> str:
        return " → ".join([self.history[0][0].value] + [h[2].value for h in self.history]) \
            if self.history else self.state.value

    def __repr__(self) -> str:
        return f"<{self.name} state={self.state.value}>"
